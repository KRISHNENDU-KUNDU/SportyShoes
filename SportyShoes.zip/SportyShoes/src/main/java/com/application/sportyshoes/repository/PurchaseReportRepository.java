package com.application.sportyshoes.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.application.sportyshoes.entity.PurchaseReport;

@Repository
public interface PurchaseReportRepository extends JpaRepository<PurchaseReport, Long> {

	public List<PurchaseReport> findByDop(Date dop);
	public List<PurchaseReport> findByCategory(String category);
}
