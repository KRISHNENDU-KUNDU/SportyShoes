package com.application.sportyshoes.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.*;



@Entity
@Table(name = "purchasereport")
public class PurchaseReport {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "purchaseId")
	private long id;
	@Column(name = "purchasedBy")
	private String purchasedBy; // This can be extended to utilize one to one relation with User Table [Future Implemetations]
	@Column(name = "purchaseCategory")
	private String category;
	@Column(name = "orderList")
	 private List<String> orderList = new ArrayList<>();
	@Temporal(TemporalType.DATE)
	private Date dop;
	
	
	
	
	public PurchaseReport() {
		// TODO Auto-generated constructor stub
	}

	

	public PurchaseReport(String purchasedBy, String category, List<String> orderList, Date dop) {
		super();
		this.purchasedBy = purchasedBy;
		this.category = category;
		this.orderList = orderList;
		this.dop = dop;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPurchasedBy() {
		return purchasedBy;
	}

	public void setPurchasedBy(String purchasedBy) {
		this.purchasedBy = purchasedBy;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getDop() {
		return dop;
	}

	public void setDop(Date dop) {
		this.dop = dop;
	}

	
	  public List<String> getOrderList() { return orderList; }
	  
	  public void setOrderList(List<String> orderList) { this.orderList = orderList; }
	 
	
	
	
	
}
