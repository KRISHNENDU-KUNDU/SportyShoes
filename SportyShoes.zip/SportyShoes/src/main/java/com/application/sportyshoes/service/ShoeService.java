package com.application.sportyshoes.service;

import java.util.List;

import com.application.sportyshoes.entity.Shoe;
import com.application.sportyshoes.exceptions.DataNotFound;

public interface ShoeService {

	public Shoe createShoe(Shoe shoe) throws DataNotFound;
	public List<Shoe> getAllShoes();
	public Shoe updateShoe(Shoe shoe,long shoeId)throws DataNotFound;
	public Shoe getShoeById(long shoeId) throws DataNotFound;
	public void deleteShoeById(long shoeId) throws DataNotFound;
}
