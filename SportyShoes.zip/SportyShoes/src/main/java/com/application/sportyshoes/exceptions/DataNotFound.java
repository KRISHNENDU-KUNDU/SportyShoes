package com.application.sportyshoes.exceptions;

public class DataNotFound extends Exception {

	public DataNotFound(String message) {
		super(message);
	}
}
