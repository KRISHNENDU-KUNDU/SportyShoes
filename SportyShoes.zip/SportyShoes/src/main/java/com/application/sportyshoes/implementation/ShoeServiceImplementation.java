package com.application.sportyshoes.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.sportyshoes.entity.Shoe;
import com.application.sportyshoes.exceptions.DataNotFound;
import com.application.sportyshoes.repository.ShoeRepository;
import com.application.sportyshoes.service.ShoeService;

@Service
public class ShoeServiceImplementation implements ShoeService{

	@Autowired
	private ShoeRepository shoerepo;
	@Override
	public Shoe createShoe(Shoe shoe) throws DataNotFound {
		
		return shoerepo.save(shoe);
	}

	@Override
	public List<Shoe> getAllShoes() {
		
		return shoerepo.findAll();
	}

	@Override
	public Shoe updateShoe(Shoe shoe, long shoeId) throws DataNotFound {
		
		Shoe existingShoe = shoerepo.findById(shoeId).get();
		if(shoe != null) {
			//update existing Customer details with new details
			existingShoe.setShoeName(shoe.getShoeName());
			existingShoe.setShoeCategory(shoe.getShoeCategory());
			existingShoe.setShoePrice(shoe.getShoePrice());
		
			//existingShoe.setReportSet(shoe.getReportSet());
			
		}else {
			throw new DataNotFound("Shoe not found");
		}
		return existingShoe;

	}

	@Override
	public Shoe getShoeById(long shoeId) throws DataNotFound {
		
		return shoerepo.findById(shoeId).get();
	}

	@Override
	public void deleteShoeById(long shoeId) throws DataNotFound {
		shoerepo.deleteById(shoeId);
		
	}

	
}
