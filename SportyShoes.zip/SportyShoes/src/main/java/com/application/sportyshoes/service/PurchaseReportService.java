package com.application.sportyshoes.service;

import java.util.Date;
import java.util.List;

import com.application.sportyshoes.entity.PurchaseReport;
import com.application.sportyshoes.exceptions.DataNotFound;



public interface PurchaseReportService {

	public PurchaseReport createPurchaseReport(PurchaseReport pr) throws DataNotFound;
	public PurchaseReport getPurchaseReportById(long purcheseId) throws DataNotFound;
	public PurchaseReport updatePurchaseReport(PurchaseReport pr,long purchaseId)throws DataNotFound;
	public void deletePurchaseReportById(long purchaseId) throws DataNotFound;
	public List<PurchaseReport> getAllPurchaseReports();
	public List<PurchaseReport> getAllPurchaseReportsByCategory(String category);
	public List<PurchaseReport> getAllPurchaseReportsByDOP(Date dop);
}
