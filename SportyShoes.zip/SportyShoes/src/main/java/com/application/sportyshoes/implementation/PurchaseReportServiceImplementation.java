package com.application.sportyshoes.implementation;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.sportyshoes.entity.PurchaseReport;
import com.application.sportyshoes.entity.Shoe;
import com.application.sportyshoes.exceptions.DataNotFound;
import com.application.sportyshoes.repository.PurchaseReportRepository;
import com.application.sportyshoes.service.PurchaseReportService;

@Service
public class PurchaseReportServiceImplementation implements PurchaseReportService{

	@Autowired
	private PurchaseReportRepository purchaserepo;
	@Override
	public PurchaseReport createPurchaseReport(PurchaseReport pr) throws DataNotFound {
		
		return purchaserepo.save(pr);
	}

	@Override
	public PurchaseReport getPurchaseReportById(long purchaseId) throws DataNotFound {
		// TODO Auto-generated method stub
		return purchaserepo.findById(purchaseId).get();
	}

	@Override
	public PurchaseReport updatePurchaseReport(PurchaseReport pr, long purchaseId) throws DataNotFound {
		
		PurchaseReport existingReport = purchaserepo.findById(purchaseId).get();
		if(pr != null) {
			//update existing Customer details with new details
			existingReport.setCategory(pr.getCategory());
			existingReport.setPurchasedBy(pr.getPurchasedBy());
			existingReport.setDop(pr.getDop());
			existingReport.setOrderList(pr.getOrderList());
			
			
		}else {
			throw new DataNotFound("Purchase Report not found");
		}
		return existingReport;
	}

	@Override
	public void deletePurchaseReportById(long purchaseId) throws DataNotFound {
		purchaserepo.deleteById(purchaseId);
		
	}

	@Override
	public List<PurchaseReport> getAllPurchaseReports() {
		
		return purchaserepo.findAll();
	}

	@Override
	public List<PurchaseReport> getAllPurchaseReportsByCategory(String category) {
		// TODO Auto-generated method stub
		return purchaserepo.findByCategory(category);
	}

	@Override
	public List<PurchaseReport> getAllPurchaseReportsByDOP(Date dop) {
		// TODO Auto-generated method stub
		return purchaserepo.findByDop(dop);
	}

}
