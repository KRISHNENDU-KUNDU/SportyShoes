package com.application.sportyshoes.entity;

import javax.persistence.*;


@Entity
@Table(name = "shoe")
public class Shoe {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "shoeId")
	private long shoeId;
	@Column(name = "shoeName")
	private String shoeName;
	@Column(name = "shoeCategory")
	private String shoeCategory;
	@Column(name = "shoePrice")
	private float shoePrice;
	
	/*
	 * @ManyToMany(mappedBy = "shoeSet")
	 * 
	 * @JsonIgnoreProperties("shoeSet") private Set<PurchaseReport> reportSet = new
	 * HashSet<PurchaseReport>();
	 */
	 public Shoe() {
		// TODO Auto-generated constructor stub
	}
	public Shoe(String shoeName, String shoeCategory, float shoePrice) {
		super();
		this.shoeName = shoeName;
		this.shoeCategory = shoeCategory;
		this.shoePrice = shoePrice;
	}
	public long getShoeId() {
		return shoeId;
	}
	public void setShoeId(long shoeId) {
		this.shoeId = shoeId;
	}
	public String getShoeName() {
		return shoeName;
	}
	public void setShoeName(String shoeName) {
		this.shoeName = shoeName;
	}
	public String getShoeCategory() {
		return shoeCategory;
	}
	public void setShoeCategory(String shoeCategory) {
		this.shoeCategory = shoeCategory;
	}
	public float getShoePrice() {
		return shoePrice;
	}
	public void setShoePrice(float shoePrice) {
		this.shoePrice = shoePrice;
	}
	/*
	 * public Set<PurchaseReport> getReportSet() { return reportSet; } public void
	 * setReportSet(Set<PurchaseReport> reportSet) { this.reportSet = reportSet; }
	 */
	
	 
}
