package com.application.sportyshoes.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.application.sportyshoes.entity.PurchaseReport;
import com.application.sportyshoes.exceptions.DataNotFound;
import com.application.sportyshoes.service.PurchaseReportService;

@RestController
@RequestMapping("/purchasereport")
public class PurchaseReportController {

	@Autowired
	private PurchaseReportService purchaseservice;
	
	@PostMapping("/createpurchasereport")
	public PurchaseReport createPurchaseReport(@RequestBody PurchaseReport pr) throws DataNotFound{
		return purchaseservice.createPurchaseReport(pr);
	}
	@GetMapping("/getpurchasereportbyid/{purchaseid}")
	public PurchaseReport getPurchaseReportById(@PathVariable("purchaseid")long purcheseId) throws DataNotFound{
		return purchaseservice.getPurchaseReportById(purcheseId);
	}
	@PutMapping("/updatepurchasereport/{purchaseid}")
	public PurchaseReport updatePurchaseReport(@RequestBody PurchaseReport pr,@PathVariable("purchaseid")long purchaseId)throws DataNotFound{
		return purchaseservice.updatePurchaseReport(pr, purchaseId);
	}
	@DeleteMapping("/deletepurchasereportbyid/{purchaseid}")
	public void deletePurchaseReportById(@PathVariable("purchaseid")long purchaseId) throws DataNotFound{
		purchaseservice.deletePurchaseReportById(purchaseId);
	}
	@GetMapping("/getallpurchasereports")
	public List<PurchaseReport> getAllPurchaseReports(){
		return purchaseservice.getAllPurchaseReports();
	}
	@GetMapping("/getallpurchasereportsbycategory/{category}")
	public List<PurchaseReport> getAllPurchaseReportsByCategory(@PathVariable("category")String category){
		return purchaseservice.getAllPurchaseReportsByCategory(category);
	}
	@GetMapping("/getallpurchasereportsbydop/{dop}")
	public List<PurchaseReport> getAllPurchaseReportsByDOP(@PathVariable("dop")Date dop){
		return purchaseservice.getAllPurchaseReportsByDOP(dop);
	}
}
