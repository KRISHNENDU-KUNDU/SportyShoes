package com.application.sportyshoes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.application.sportyshoes.entity.Shoe;
import com.application.sportyshoes.exceptions.DataNotFound;
import com.application.sportyshoes.service.ShoeService;

@RestController
@RequestMapping("/shoe")
public class ShoeController {
	@Autowired
	private ShoeService shoeservice;
	@PostMapping("/createshoes")
	public Shoe createShoe(@RequestBody Shoe shoe) throws DataNotFound{
		return shoeservice.createShoe(shoe);
	}
	@GetMapping("/getallshoes")
	public List<Shoe> getAllShoes(){
		return shoeservice.getAllShoes();
	}
	@PutMapping("/updateshoe/{shoeid}")
	public Shoe updateShoe(@RequestBody Shoe shoe,@PathVariable("shoeid") long shoeId)throws DataNotFound{
		return shoeservice.updateShoe(shoe, shoeId);
	}
	@GetMapping("/getshoebyid/{shoeid}")
	public Shoe getShoeById(@PathVariable("shoeid")long shoeId) throws DataNotFound{
		return shoeservice.getShoeById(shoeId);
	}
	@DeleteMapping("/deleteshoebyid/{shoeid}")
	public void deleteShoeById(@PathVariable("shoeid")long shoeId) throws DataNotFound{
		shoeservice.deleteShoeById(shoeId);
	}
}
